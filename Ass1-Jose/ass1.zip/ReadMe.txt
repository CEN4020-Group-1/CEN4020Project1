Language: C++
OS: Windows 11

Compilation Command: g++ -std=c++17  ass1.cpp -o ass1